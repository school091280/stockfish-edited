/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2026 The Stockfish developers (see AUTHORS file)

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "movepick.h"

#include <cassert>
#include <limits>
#include <utility>

#include "bitboard.h"
#include "misc.h"
#include "position.h"

namespace Stockfish {

namespace {

enum Stages {
    // generate main search moves
    MAIN_TT,
    CAPTURE_INIT,
    GOOD_CAPTURE,
    QUIET_INIT,
    GOOD_QUIET,
    BAD_CAPTURE,
    BAD_QUIET,

    // generate quiet-first main search moves
    QFIRST_TT,
    QFIRST_INIT,
    QFIRST_GOOD,
    QFIRST_GOOD_CAPTURE,
    QFIRST_BAD_CAPTURE,
    QFIRST_BAD_QUIET,

    // generate evasion moves
    EVASION_TT,
    EVASION_INIT,
    EVASION,

    // generate probcut moves
    PROBCUT_TT,
    PROBCUT_INIT,
    PROBCUT,

    // generate qsearch moves
    QSEARCH_TT,
    QCAPTURE_INIT,
    QCAPTURE
};

#ifdef USE_AVX512
// Load the Move, and the ExtMove value, into all lanes of 512-bit registers
static void splat_extmove(const ExtMove& m, __m512i& move, __m512i& value) {
    move  = _mm512_set1_epi32(m.raw());
    value = _mm512_set1_epi32(m.value);
}

// Sorts up to 16 moves.
struct MoveSorter {
    static constexpr int MAX_ELEMENTS = 16;
    __m512i              sortedValues, sortedMoves;

    explicit MoveSorter(const ExtMove& first) {
        splat_extmove(first, sortedMoves, sortedValues);

        // Set the uninitialized move values to INT_MIN, so that they sort less than any other move
        sortedValues = _mm512_mask_set1_epi32(sortedValues, ~1, std::numeric_limits<int>::min());
    }

    void insert(const ExtMove& m) {
        __m512i move, value;
        splat_extmove(m, move, value);

        // Mask of all elements except the insertion point
        assert(m.value != std::numeric_limits<int>::min());
        const u16 expand = _kadd_mask16(_mm512_cmplt_epi32_mask(sortedValues, value), -1);

        sortedValues = _mm512_mask_expand_epi32(value, expand, sortedValues);
        sortedMoves  = _mm512_mask_expand_epi32(move, expand, sortedMoves);
    }

    void write_sorted(ExtMove* moves, isize count) const {
        static_assert(sizeof(ExtMove) == 8);
        assert(count <= MAX_ELEMENTS);

        // Because values and moves are stored separately, we need to reassemble the ExtMoves
        auto write = [&](int offset, const __m512i indices) {
            const __m512i extMoves = _mm512_permutex2var_epi32(sortedMoves, indices, sortedValues);
            const isize   storeCount = count - offset;

            if (storeCount > 0)
                _mm512_mask_storeu_epi64(moves + offset, (1 << storeCount) - 1, extMoves);
        };

        write(0, _mm512_setr_epi32(0, 16, 1, 17, 2, 18, 3, 19, 4, 20, 5, 21, 6, 22, 7, 23));
        write(8, _mm512_setr_epi32(8, 24, 9, 25, 10, 26, 11, 27, 12, 28, 13, 29, 14, 30, 15, 31));
    }
};
#endif

// Sort moves in descending order up to and including a given limit.
// The order of moves smaller than the limit is left unspecified.
void partial_insertion_sort(ExtMove* begin, ExtMove* end, int limit) {
    ExtMove *sortedEnd = begin, *p = begin + 1;

#ifdef USE_AVX512
    if (begin == end)
        return;

    MoveSorter sorter(*begin);
    for (; p < end; ++p)
    {
        if (p->value >= limit)
        {
            if (sortedEnd - begin + 1 >= MoveSorter::MAX_ELEMENTS)  // sorter full
                break;

            sorter.insert(*p);
            *p = *++sortedEnd;
        }
    }
    sorter.write_sorted(begin, sortedEnd - begin + 1);
    // Use scalar implementation for any remaining elements
#endif

    for (; p < end; ++p)
        if (p->value >= limit)
        {
            ExtMove tmp = *p, *q;
            *p          = *++sortedEnd;
            for (q = sortedEnd; q != begin && *(q - 1) < tmp; --q)
                *q = *(q - 1);
            *q = tmp;
        }
}

}  // namespace


// Constructors of the MovePicker class. As arguments, we pass information
// to decide which class of moves to emit, to help sorting the (presumably)
// good moves first, and how important move ordering is at the current node.

// MovePicker constructor for the main search and for the quiescence search
MovePicker::MovePicker(const Position&              p,
                       Move                         ttm,
                       Depth                        d,
                       const ButterflyHistory*      mh,
                       const LowPlyHistory*         lph,
                       const CapturePieceToHistory* cph,
                       const PieceToHistory**       ch,
                       const SharedHistories*       sh,
                       int                          pl) :
    pos(p),
    mainHistory(mh),
    lowPlyHistory(lph),
    captureHistory(cph),
    continuationHistory(ch),
    sharedHistory(sh),
    ttMove(ttm),
    depth(d),
    ply(pl) {

    if (pos.checkers())
        stage = EVASION_TT + !(ttm && pos.legal(ttm));

    else if (depth <= 0)
        stage = QSEARCH_TT + !(ttm && pos.legal(ttm));

    else
    {
        // Main search. Calculate strategic state once per MovePicker instance.
        mainSearch = true;
        const int totalPawns = pos.count<PAWN>(WHITE) + pos.count<PAWN>(BLACK);

        // Branchless bias selection. The pawn-count bucket is clamped to
        // [0, 3]; the capture-bias table is indexed by it directly. The
        // quiet-bias path (openFiles lookup) is reached only when
        // totalPawns >= 12, otherwise quietBiasPct/captureMul stay at the
        // no-op defaults.
        static constexpr int captureBiasByPawns[4] = {20, 5, 0, 0};
        const int            pawnBucket            = totalPawns < 7   ? 0
                                                     : totalPawns <= 9  ? 1
                                                     : totalPawns <= 11 ? 2
                                                                        : 3;
        captureBiasPct = captureBiasByPawns[pawnBucket];
        captureMul     = 100 + captureBiasPct;

        if (pawnBucket == 3)
        {
            const Bitboard pawns = pos.pieces(PAWN);
            int            openFiles = 0;
            for (File f = FILE_A; f <= FILE_H; ++f)
                openFiles += !(pawns & file_bb(f));

            static constexpr int biasByOpenFiles[4] = {35, 10, 5, 1};
            const int            o                 = openFiles < 3 ? openFiles : 3;
            quietBiasPct = biasByOpenFiles[o];
            quietMul     = 100 + quietBiasPct;

            // Quiet-first only in the very specific endgame-like configuration
            // spelled out by the experiment.
            quietFirst = (openFiles == 0) & (ply >= 38);
        }

        const int ttOk = (ttm && pos.legal(ttm)) ? 0 : 1;
        stage = (quietFirst ? QFIRST_TT : MAIN_TT) + ttOk;
    }
}

// MovePicker constructor for ProbCut: we generate captures with Static Exchange
// Evaluation (SEE) greater than or equal to the given threshold.
MovePicker::MovePicker(const Position& p, Move ttm, int th, const CapturePieceToHistory* cph) :
    pos(p),
    captureHistory(cph),
    ttMove(ttm),
    threshold(th) {
    assert(!pos.checkers());

    stage = PROBCUT_TT + !(ttm && pos.capture_stage(ttm) && pos.legal(ttm));
}

// Assigns a numerical value to each move in a list, used for sorting.
// Captures are ordered by Most Valuable Victim (MVV), preferring captures
// with a good history. Quiet moves are ordered using the history tables.
template<GenType Type>
ExtMove* MovePicker::score(const MoveList<Type>& ml) {

    static_assert(Type == CAPTURES || Type == QUIETS || Type == EVASIONS, "Wrong type");

    Color us = pos.side_to_move();

    [[maybe_unused]] Bitboard threatByLesser[KING + 1];
    if constexpr (Type == QUIETS)
    {
        threatByLesser[PAWN]   = 0;
        threatByLesser[KNIGHT] = threatByLesser[BISHOP] = pos.threats_by(PAWN);
        threatByLesser[ROOK] =
          pos.threats_by(KNIGHT) | pos.threats_by(BISHOP) | threatByLesser[KNIGHT];
        threatByLesser[QUEEN] = pos.threats_by(ROOK) | threatByLesser[ROOK];
        threatByLesser[KING]  = 0;
    }

    ExtMove* it = cur;
    for (auto move : ml)
    {
        ExtMove& m = *it++;
        m          = move;

        const Square    from          = m.from_sq();
        const Square    to            = m.to_sq();
        const Piece     pc            = pos.moved_piece(m);
        const PieceType pt            = type_of(pc);
        const Piece     capturedPiece = pos.piece_on(to);

        if constexpr (Type == CAPTURES)
        {
            m.value = ((*captureHistory)[pc][to][type_of(capturedPiece)]
                     + 7 * int(PieceValue[capturedPiece])) * captureMul / 100;
        }

        else if constexpr (Type == QUIETS)
        {
            // Use a local accumulator to eliminate redundant stores to m.value

            // histories
            int value = 2 * (*mainHistory)[us][m.raw()];
            value += 2 * sharedHistory->pawn_entry(pos)[pc][to];
            value += (*continuationHistory[0])[pc][to];
            value += (*continuationHistory[1])[pc][to];
            value += (*continuationHistory[2])[pc][to];
            value += (*continuationHistory[3])[pc][to];
            value += (*continuationHistory[5])[pc][to];

            // bonus for checks
            value += ((pos.check_squares(pt) & to) && pos.see_ge(m, -75)) * 16384;

            // penalty for moving to a square threatened by a lesser piece
            // or bonus for escaping an attack by a lesser piece.
            int v = 20 * (bool(threatByLesser[pt] & from) - bool(threatByLesser[pt] & to));
            value += PieceValue[pt] * v;


            if (ply < LOW_PLY_HISTORY_SIZE)
                value += 8 * (*lowPlyHistory)[ply][m.raw()] / (1 + ply);

            m.value = value * quietMul / 100;
        }

        else  // Type == EVASIONS
        {
            m.value = pos.capture_stage(m)
                      ? PieceValue[capturedPiece] + (1 << 28)
                      : (*mainHistory)[us][m.raw()] + (*continuationHistory[0])[pc][to];
        }
    }
    return it;
}

// Returns the next move satisfying a predicate function.
// This never returns the TT move, as it was emitted before.
template<typename Pred>
Move MovePicker::select(Pred filter) {

    for (; cur < endCur; ++cur)
        if (*cur != ttMove && filter())
            return *cur++;

    return Move::none();
}

// This is the most important method of the MovePicker class. We emit one
// new legal move on every call until there are no more moves left,
// picking the move with the highest score from a list of generated moves.
Move MovePicker::next_move() {

    constexpr int goodQuietThreshold = -14000;
top:
    switch (stage)
    {

    case MAIN_TT :
    case EVASION_TT :
    case QSEARCH_TT :
    case PROBCUT_TT :
        ++stage;
        return ttMove;

    case CAPTURE_INIT :
    case PROBCUT_INIT :
    case QCAPTURE_INIT : {
        MoveList<CAPTURES> ml(pos);

        cur = endBadCaptures = moves;
        endCur = endCaptures = score<CAPTURES>(ml);

        partial_insertion_sort(cur, endCur, std::numeric_limits<int>::min());
        ++stage;
        goto top;
    }

    case GOOD_CAPTURE :
        if (select([&]() {
                if (pos.see_ge(*cur, -cur->value / 18))
                    return true;
                std::swap(*endBadCaptures++, *cur);
                return false;
            }))
            return *(cur - 1);

        ++stage;
        [[fallthrough]];

    case QUIET_INIT :
        if (!skipQuiets)
        {
            MoveList<QUIETS> ml(pos);

            endCur = endGenerated = score<QUIETS>(ml);

            partial_insertion_sort(cur, endCur, -3560 * depth);
        }

        ++stage;
        [[fallthrough]];

    case GOOD_QUIET :
        if (!skipQuiets && select([&]() { return cur->value > goodQuietThreshold; }))
            return *(cur - 1);

        // Prepare the pointers to loop over the bad captures
        cur    = moves;
        endCur = endBadCaptures;

        ++stage;
        [[fallthrough]];

    case BAD_CAPTURE :
        if (select([]() { return true; }))
            return *(cur - 1);

        // Prepare the pointers to loop over quiets again
        cur    = endCaptures;
        endCur = endGenerated;

        ++stage;
        [[fallthrough]];

    case BAD_QUIET :
        if (!skipQuiets)
            return select([&]() { return cur->value <= goodQuietThreshold; });

        return Move::none();

    case QFIRST_TT :
        ++stage;
        return ttMove;

    case QFIRST_INIT : {
        // Generate quiets first. They occupy [moves, endGenerated).
        cur            = moves;
        endCaptures    = moves;  // captures will start here later
        endBadCaptures = moves;
        if (!skipQuiets)
        {
            MoveList<QUIETS> ml(pos);
            endCur = endGenerated = score<QUIETS>(ml);
            partial_insertion_sort(cur, endCur, -3560 * depth);
        }
        else
        {
            endCur = endGenerated = moves;
        }
        ++stage;
        [[fallthrough]];
    }

    case QFIRST_GOOD :
        if (!skipQuiets && select([&]() { return cur->value > goodQuietThreshold; }))
            return *(cur - 1);

        // Generate captures now. They go at the tail of moves[] (right
        // after endGenerated). total moves never exceed MAX_MOVES, so the
        // buffer is large enough for quiets + captures.
        {
            MoveList<CAPTURES> ml(pos);
            cur            = endGenerated;
            endBadCaptures = cur;
            ExtMove* capEnd = score<CAPTURES>(ml);
            endCaptures    = capEnd;
            partial_insertion_sort(cur, capEnd, std::numeric_limits<int>::min());
        }
        ++stage;
        [[fallthrough]];

    case QFIRST_GOOD_CAPTURE :
        // cur is at start of captures; iterate over the full capture range.
        endCur = endCaptures;
        if (select([&]() {
                if (pos.see_ge(*cur, -cur->value / 18))
                    return true;
                std::swap(*endBadCaptures++, *cur);
                return false;
            }))
            return *(cur - 1);

        ++stage;
        [[fallthrough]];

    case QFIRST_BAD_CAPTURE :
        // Bad captures were swapped to the front of the capture region
        // [endGenerated, endCaptures). endBadCaptures marks the boundary.
        cur    = endGenerated;
        endCur = endBadCaptures;
        if (select([]() { return true; }))
            return *(cur - 1);

        // Bad quiets: [moves, endGenerated) with value <= goodQuietThreshold
        cur    = moves;
        endCur = endGenerated;

        ++stage;
        [[fallthrough]];

    case QFIRST_BAD_QUIET :
        if (!skipQuiets)
            return select([&]() { return cur->value <= goodQuietThreshold; });

        return Move::none();

    case EVASION_INIT : {
        MoveList<EVASIONS> ml(pos);

        cur    = moves;
        endCur = endGenerated = score<EVASIONS>(ml);

        partial_insertion_sort(cur, endCur, std::numeric_limits<int>::min());
        ++stage;
        [[fallthrough]];
    }

    case EVASION :
    case QCAPTURE :
        return select([]() { return true; });

    case PROBCUT :
        return select([&]() { return pos.see_ge(*cur, threshold); });
    }

    assert(false);
    return Move::none();  // Silence warning
}

void MovePicker::skip_quiet_moves() { skipQuiets = true; }

}  // namespace Stockfish
